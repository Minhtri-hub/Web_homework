import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export function matchFieldsValidator(field: string, confirmField: string): ValidatorFn {
  return (group: AbstractControl): ValidationErrors | null => {
    const first = group.get(field)?.value;
    const second = group.get(confirmField)?.value;
    return first === second ? null : { fieldsMismatch: true };
  };
}

export function dateRangeValidator(startField: string, endField: string): ValidatorFn {
  return (group: AbstractControl): ValidationErrors | null => {
    const startValue = group.get(startField)?.value;
    const endValue = group.get(endField)?.value;

    if (!startValue || !endValue) {
      return null;
    }

    return new Date(startValue) <= new Date(endValue) ? null : { invalidDateRange: true };
  };
}

