export interface IProductImage {
  ProductId: string;
  ProductName: string;
  Price: number;
  Image: string;
}

