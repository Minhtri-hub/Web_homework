export interface LunarYearDetail {
  weekday: string;
  lunarDateText: string;
  lunarYearName: string;
  lunarMonthName: string;
  lunarDayName: string;
}

export class LunarYear {
  private static readonly CAN = ['Giáp', 'Ất', 'Bính', 'Đinh', 'Mậu', 'Kỷ', 'Canh', 'Tân', 'Nhâm', 'Quý'];
  private static readonly CHI = ['Tý', 'Sửu', 'Dần', 'Mão', 'Thìn', 'Tỵ', 'Ngọ', 'Mùi', 'Thân', 'Dậu', 'Tuất', 'Hợi'];

  constructor(
    private day: number,
    private month: number,
    private year: number
  ) {}

  findLunarYearDetail(): LunarYearDetail {
    const lunar = this.convertSolar2Lunar(this.day, this.month, this.year, 7);
    const jd = this.jdFromDate(this.day, this.month, this.year);

    return {
      weekday: this.getWeekdayText(this.day, this.month, this.year),
      lunarDateText: `${lunar.day}/${lunar.month}/${lunar.year}${lunar.leap ? ' (Nhuận)' : ''}`,
      lunarYearName: this.getCanChiYear(lunar.year),
      lunarMonthName: this.getCanChiMonth(lunar.month, lunar.year),
      lunarDayName: this.getCanChiDay(jd),
    };
  }

  private getWeekdayText(dd: number, mm: number, yy: number): string {
    const dayIndex = new Date(yy, mm - 1, dd).getDay();
    if (dayIndex === 0) {
      return 'Ngày chủ nhật';
    }
    return `Ngày thứ ${dayIndex + 1}`;
  }

  private getCanChiYear(year: number): string {
    return `${LunarYear.CAN[(year + 6) % 10]} ${LunarYear.CHI[(year + 8) % 12]}`;
  }

  private getCanChiMonth(month: number, year: number): string {
    return `${LunarYear.CAN[(year * 12 + month + 3) % 10]} ${LunarYear.CHI[(month + 1) % 12]}`;
  }

  private getCanChiDay(jd: number): string {
    return `${LunarYear.CAN[(jd + 9) % 10]} ${LunarYear.CHI[(jd + 1) % 12]}`;
  }

  private int(d: number): number {
    return Math.floor(d);
  }

  private jdFromDate(dd: number, mm: number, yy: number): number {
    const a = this.int((14 - mm) / 12);
    const y = yy + 4800 - a;
    const m = mm + 12 * a - 3;
    let jd = dd + this.int((153 * m + 2) / 5) + 365 * y + this.int(y / 4) - this.int(y / 100) + this.int(y / 400) - 32045;
    if (jd < 2299161) {
      jd = dd + this.int((153 * m + 2) / 5) + 365 * y + this.int(y / 4) - 32083;
    }
    return jd;
  }

  private getNewMoonDay(k: number, timeZone: number): number {
    const T = k / 1236.85;
    const T2 = T * T;
    const T3 = T2 * T;
    const dr = Math.PI / 180;
    let jd1 = 2415020.75933 + 29.53058868 * k + 0.0001178 * T2 - 0.000000155 * T3;
    jd1 += 0.00033 * Math.sin((166.56 + 132.87 * T - 0.009173 * T2) * dr);
    const M = 359.2242 + 29.10535608 * k - 0.0000333 * T2 - 0.00000347 * T3;
    const Mpr = 306.0253 + 385.81691806 * k + 0.0107306 * T2 + 0.00001236 * T3;
    const F = 21.2964 + 390.67050646 * k - 0.0016528 * T2 - 0.00000239 * T3;
    let c1 = (0.1734 - 0.000393 * T) * Math.sin(M * dr) + 0.0021 * Math.sin(2 * dr * M);
    c1 -= 0.4068 * Math.sin(Mpr * dr) + 0.0161 * Math.sin(dr * 2 * Mpr);
    c1 -= 0.0004 * Math.sin(dr * 3 * Mpr);
    c1 += 0.0104 * Math.sin(dr * 2 * F) - 0.0051 * Math.sin(dr * (M + Mpr));
    c1 -= 0.0074 * Math.sin(dr * (M - Mpr)) + 0.0004 * Math.sin(dr * (2 * F + M));
    c1 -= 0.0004 * Math.sin(dr * (2 * F - M)) - 0.0006 * Math.sin(dr * (2 * F + Mpr));
    c1 += 0.001 * Math.sin(dr * (2 * F - Mpr)) + 0.0005 * Math.sin(dr * (2 * Mpr + M));
    let deltaT;
    if (T < -11) {
      deltaT = 0.001 + 0.000839 * T + 0.0002261 * T2 - 0.00000845 * T3 - 0.000000081 * T * T3;
    } else {
      deltaT = -0.000278 + 0.000265 * T + 0.000262 * T2;
    }
    const jdNew = jd1 + c1 - deltaT;
    return this.int(jdNew + 0.5 + timeZone / 24);
  }

  private getSunLongitude(dayNumber: number, timeZone: number): number {
    const T = (dayNumber - 2451545.5 - timeZone / 24) / 36525;
    const T2 = T * T;
    const dr = Math.PI / 180;
    const M = 357.52910 + 35999.05030 * T - 0.0001559 * T2 - 0.00000048 * T * T2;
    const L0 = 280.46645 + 36000.76983 * T + 0.0003032 * T2;
    let DL = (1.914600 - 0.004817 * T - 0.000014 * T2) * Math.sin(dr * M);
    DL += (0.019993 - 0.000101 * T) * Math.sin(dr * 2 * M) + 0.000290 * Math.sin(dr * 3 * M);
    const L = L0 + DL;
    const omega = L * dr;
    return this.int((omega / Math.PI) * 6);
  }

  private getLunarMonth11(yy: number, timeZone: number): number {
    const off = this.jdFromDate(31, 12, yy) - 2415021;
    const k = this.int(off / 29.530588853);
    let nm = this.getNewMoonDay(k, timeZone);
    const sunLong = this.getSunLongitude(nm, timeZone);
    if (sunLong >= 9) {
      nm = this.getNewMoonDay(k - 1, timeZone);
    }
    return nm;
  }

  private getLeapMonthOffset(a11: number, timeZone: number): number {
    const k = this.int((a11 - 2415021.076998695) / 29.530588853 + 0.5);
    let last = 0;
    let i = 1;
    let arc = this.getSunLongitude(this.getNewMoonDay(k + i, timeZone), timeZone);
    do {
      last = arc;
      i += 1;
      arc = this.getSunLongitude(this.getNewMoonDay(k + i, timeZone), timeZone);
    } while (arc !== last && i < 14);
    return i - 1;
  }

  private convertSolar2Lunar(dd: number, mm: number, yy: number, timeZone: number): { day: number; month: number; year: number; leap: number } {
    const dayNumber = this.jdFromDate(dd, mm, yy);
    const k = this.int((dayNumber - 2415021.076998695) / 29.530588853);
    let monthStart = this.getNewMoonDay(k + 1, timeZone);
    if (monthStart > dayNumber) {
      monthStart = this.getNewMoonDay(k, timeZone);
    }
    let a11 = this.getLunarMonth11(yy, timeZone);
    let b11 = a11;
    let lunarYear;
    if (a11 >= monthStart) {
      lunarYear = yy;
      a11 = this.getLunarMonth11(yy - 1, timeZone);
    } else {
      lunarYear = yy + 1;
      b11 = this.getLunarMonth11(yy + 1, timeZone);
    }
    const lunarDay = dayNumber - monthStart + 1;
    const diff = this.int((monthStart - a11) / 29);
    let lunarLeap = 0;
    let lunarMonth = diff + 11;
    if (b11 - a11 > 365) {
      const leapMonthDiff = this.getLeapMonthOffset(a11, timeZone);
      if (diff >= leapMonthDiff) {
        lunarMonth = diff + 10;
        if (diff === leapMonthDiff) {
          lunarLeap = 1;
        }
      }
    }
    if (lunarMonth > 12) {
      lunarMonth -= 12;
    }
    if (lunarMonth >= 11 && diff < 4) {
      lunarYear -= 1;
    }
    return { day: lunarDay, month: lunarMonth, year: lunarYear, leap: lunarLeap };
  }
}

