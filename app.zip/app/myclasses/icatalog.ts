export interface ICategoryProduct {
  ProductId: string;
  ProductName: string;
  Price: number;
  Image: string;
}

export interface ICatalog {
  Cateid: string;
  CateName: string;
  Products: ICategoryProduct[];
}

