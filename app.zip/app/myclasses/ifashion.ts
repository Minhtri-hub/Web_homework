export interface IFashion {
  FashionId: string;
  FashionName: string;
  Price: number;
  Image: string;
}

