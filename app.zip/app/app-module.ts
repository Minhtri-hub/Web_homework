﻿import { NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing-module';
import { App } from './app';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { Ex13 } from './ex13/ex13';
import { Ex14 } from './ex14/ex14';
import { Fakeproduct } from './fakeproduct/fakeproduct';
import { Books } from './books/books';
import { BookDetail } from './book-detail/book-detail';
import { NewBook } from './new-book/new-book';
import { ServiceProductImageEvent } from './service-product-image-event/service-product-image-event';
import { ServiceProductImageEventDetail } from './service-product-image-event-detail/service-product-image-event-detail';
import { TemplateDrivenForm } from './template-driven-form/template-driven-form';
import { ReactiveFormDemo } from './reactive-form-demo/reactive-form-demo';
import { Product } from './product/product';
import { ListProduct } from './list-product/list-product';
import { ServiceProduct } from './service-product/service-product';
import { NeonatalFeedingStudy } from './neonatal-feeding-study/neonatal-feeding-study';
import { Ex10Lunar } from './ex10-lunar/ex10-lunar';
import { Ex27ColorPicker } from './ex27-color-picker/ex27-color-picker';
import { Ex28StringTools } from './ex28-string-tools/ex28-string-tools';
import { Ex58Fashion } from './ex58-fashion/ex58-fashion';
import { Ex60UpdateFashion } from './ex60-update-fashion/ex60-update-fashion';
import { Ex61DeleteFashion } from './ex61-delete-fashion/ex61-delete-fashion';
import { Ex63CookieSession } from './ex63-cookie-session/ex63-cookie-session';

@NgModule({
  declarations: [
    App,
    Ex13,
    Ex14,
    Fakeproduct,
    Books,
    BookDetail,
    NewBook,
    ServiceProductImageEvent,
    ServiceProductImageEventDetail,
    TemplateDrivenForm,
    ReactiveFormDemo,
    Product,
    ListProduct,
    ServiceProduct,
    NeonatalFeedingStudy,
    Ex10Lunar,
    Ex27ColorPicker,
    Ex28StringTools,
    Ex58Fashion,
    Ex60UpdateFashion,
    Ex61DeleteFashion,
    Ex63CookieSession
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
  ],
  providers: [
    provideBrowserGlobalErrorListeners(),
  ],
  bootstrap: [App]
})
export class AppModule { }

