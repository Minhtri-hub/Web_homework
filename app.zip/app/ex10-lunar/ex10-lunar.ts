import { Component } from '@angular/core';
import { LunarYear, LunarYearDetail } from '../myclasses/lunar-year';

@Component({
  selector: 'app-ex10-lunar',
  standalone: false,
  templateUrl: './ex10-lunar.html',
  styleUrl: './ex10-lunar.css',
})
export class Ex10Lunar {
  days: number[] = Array.from({ length: 31 }, (_, i) => i + 1);
  months: number[] = Array.from({ length: 12 }, (_, i) => i + 1);
  years: number[] = Array.from({ length: 151 }, (_, i) => 1950 + i);

  selectedDay = 15;
  selectedMonth = 5;
  selectedYear = 1986;

  detail: LunarYearDetail = {
    weekday: '',
    lunarDateText: '',
    lunarYearName: '',
    lunarMonthName: '',
    lunarDayName: '',
  };

  constructor() {
    this.convert();
  }

  convert(): void {
    const lunar = new LunarYear(this.selectedDay, this.selectedMonth, this.selectedYear);
    this.detail = lunar.findLunarYearDetail();
  }
}

