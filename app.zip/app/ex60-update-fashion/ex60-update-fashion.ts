import { Component } from '@angular/core';
import { IFashion } from '../myclasses/ifashion';
import { FashionAPIService } from '../myservice/fashion-api-service';

@Component({
  selector: 'app-ex60-update-fashion',
  standalone: false,
  templateUrl: './ex60-update-fashion.html',
  styleUrl: './ex60-update-fashion.css',
})
export class Ex60UpdateFashion {
  fashions: IFashion[] = [];
  errMessage = '';
  selectedId = '';
  form: IFashion = { FashionId: '', FashionName: '', Price: 0, Image: '' };

  constructor(private _service: FashionAPIService) {
    this.loadData();
  }

  loadData(): void {
    this._service.getFashions().subscribe({
      next: (data) => {
        this.fashions = data;
      },
      error: (err) => {
        this.errMessage = err.message || String(err);
      },
    });
  }

  onSelectId(): void {
    const found = this.fashions.find((x) => x.FashionId === this.selectedId);
    if (!found) {
      return;
    }
    this.form = { ...found };
  }

  updateFashion(): void {
    this._service.updateFashion(this.form).subscribe({
      next: (data) => {
        this.fashions = data;
        this.errMessage = 'Update success.';
      },
      error: (err) => {
        this.errMessage = err.message || String(err);
      },
    });
  }
}

