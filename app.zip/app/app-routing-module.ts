import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Fakeproduct } from './fakeproduct/fakeproduct';
import { Ex14 } from './ex14/ex14';
import { Books } from './books/books';
import { BookDetail } from './book-detail/book-detail';
import { ServiceProductImageEvent } from './service-product-image-event/service-product-image-event';
import { ServiceProductImageEventDetail } from './service-product-image-event-detail/service-product-image-event-detail';
import { TemplateDrivenForm } from './template-driven-form/template-driven-form';
import { ReactiveFormDemo } from './reactive-form-demo/reactive-form-demo';
import { Product } from './product/product';
import { ListProduct } from './list-product/list-product';
import { ServiceProduct } from './service-product/service-product';
import { NeonatalFeedingStudy } from './neonatal-feeding-study/neonatal-feeding-study';
import { Ex10Lunar } from './ex10-lunar/ex10-lunar';
import { Ex27ColorPicker } from './ex27-color-picker/ex27-color-picker';
import { Ex28StringTools } from './ex28-string-tools/ex28-string-tools';
import { Ex58Fashion } from './ex58-fashion/ex58-fashion';
import { Ex60UpdateFashion } from './ex60-update-fashion/ex60-update-fashion';
import { Ex61DeleteFashion } from './ex61-delete-fashion/ex61-delete-fashion';
import { Ex63CookieSession } from './ex63-cookie-session/ex63-cookie-session';


const routes: Routes = [
  { path: 'ex26', component: NeonatalFeedingStudy },
  { path: 'ex10', component: Ex10Lunar },
  { path: 'ex27', component: Ex27ColorPicker },
  { path: 'ex28', component: Ex28StringTools },
  { path: 'ex58', component: Ex58Fashion },
  { path: 'ex60', component: Ex60UpdateFashion },
  { path: 'ex61', component: Ex61DeleteFashion },
  { path: 'ex63', component: Ex63CookieSession },
  { path: 'fakeproduct', component: Fakeproduct },
  { path: 'service-product-image-event', component: ServiceProductImageEvent },
  { path: 'service-product-image-event/:id', component: ServiceProductImageEventDetail },
  { path: 'product', component: Product },
  { path: 'list-product', component: ListProduct },
  { path: 'service-product', component: ServiceProduct },
  { path: 'forms/template', component: TemplateDrivenForm },
  { path: 'forms/reactive', component: ReactiveFormDemo },
  { path: 'ex14', component: Ex14 },
  { path: 'ex39', component: Books },
  { path: 'ex41', component: BookDetail },
  { path: '', redirectTo: 'ex26', pathMatch: 'full' },
  { path: '**', redirectTo: 'ex26' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
