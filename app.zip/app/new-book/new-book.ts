import { Component } from '@angular/core';

@Component({
  selector: 'app-new-book',
  standalone: false,
  templateUrl: './new-book.html',
  styleUrl: './new-book.css',
})
export class NewBook {

}
