import { Component } from '@angular/core';
import { ICatalog } from '../myclasses/icatalog';
import { CatalogService } from '../myservice/catalog-service';

@Component({
  selector: 'app-ex14',
  standalone: false,
  templateUrl: './ex14.html',
  styleUrl: './ex14.css',
})
export class Ex14 {
  categories: ICatalog[] = [];

  constructor(private _service: CatalogService) {
    this.categories = this._service.getCategories();
  }
}

