import { Injectable } from '@angular/core';
import { IProductImage } from '../myclasses/iproduct-image';

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  private productsImage: IProductImage[] = [
    {
      ProductId: 'p1',
      ProductName: 'Coca',
      Price: 100,
      Image: 'assets/h1.png',
    },
    {
      ProductId: 'p2',
      ProductName: 'Pepsi',
      Price: 300,
      Image: 'assets/h2.png',
    },
    {
      ProductId: 'p3',
      ProductName: 'Sting',
      Price: 200,
      Image: 'assets/h3.png',
    },
  ];

  constructor() {}

  getProductsWithImages(): IProductImage[] {
    return this.productsImage;
  }

  getProductDetail(id: string): IProductImage | undefined {
    return this.productsImage.find((x) => x.ProductId === id);
  }
}

