import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, retry, throwError } from 'rxjs';
import { IFashion } from '../myclasses/ifashion';

@Injectable({
  providedIn: 'root',
})
export class FashionAPIService {
  private _url = 'http://localhost:3000/fashion';

  constructor(private _http: HttpClient) {}

  getFashions(): Observable<IFashion[]> {
    return this._http.get<IFashion[]>(this._url).pipe(
      retry(2),
      catchError(this.handleError)
    );
  }

  updateFashion(item: IFashion): Observable<IFashion[]> {
    return this._http.put<IFashion[]>(this._url, item).pipe(
      catchError(this.handleError)
    );
  }

  deleteFashion(id: string): Observable<IFashion[]> {
    return this._http.delete<IFashion[]>(`${this._url}/${id}`).pipe(
      catchError(this.handleError)
    );
  }

  handleError(error: HttpErrorResponse) {
    return throwError(() => new Error(error.message));
  }
}
