import { Component } from '@angular/core';
import { IFashion } from '../myclasses/ifashion';
import { FashionAPIService } from '../myservice/fashion-api-service';

@Component({
  selector: 'app-ex61-delete-fashion',
  standalone: false,
  templateUrl: './ex61-delete-fashion.html',
  styleUrl: './ex61-delete-fashion.css',
})
export class Ex61DeleteFashion {
  fashions: IFashion[] = [];
  errMessage = '';
  selectedId = '';

  constructor(private _service: FashionAPIService) {
    this.loadData();
  }

  loadData(): void {
    this._service.getFashions().subscribe({
      next: (data) => {
        this.fashions = data;
      },
      error: (err) => {
        this.errMessage = err.message || String(err);
      },
    });
  }

  deleteFashion(): void {
    if (!this.selectedId) {
      this.errMessage = 'Please select a FashionId.';
      return;
    }

    this._service.deleteFashion(this.selectedId).subscribe({
      next: (data) => {
        this.fashions = data;
        this.errMessage = 'Delete success.';
        this.selectedId = '';
      },
      error: (err) => {
        this.errMessage = err.message || String(err);
      },
    });
  }
}

