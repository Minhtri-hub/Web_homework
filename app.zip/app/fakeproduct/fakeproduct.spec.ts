import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Fakeproduct } from './fakeproduct';

describe('Fakeproduct', () => {
  let component: Fakeproduct;
  let fixture: ComponentFixture<Fakeproduct>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Fakeproduct]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Fakeproduct);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
