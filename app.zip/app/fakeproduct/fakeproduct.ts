import { Component } from '@angular/core';
import { FakeProductService } from '../myservice/fake-product-service';

@Component({
  selector: 'app-fakeproduct',
  standalone: false,
  templateUrl: './fakeproduct.html',
  styleUrl: './fakeproduct.css',
})
export class Fakeproduct {
 data:any 
  errMessage:string='' 
  constructor(_service:FakeProductService){ 
    _service.getFakeProductData().subscribe({ 
      next:(data)=>{ this.data=data}, 
      error:(err)=>{ 
        this.errMessage=err         
      } 
    }) 
  }
}
